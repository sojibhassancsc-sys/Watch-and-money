import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../services/wallet_provider.dart';
import 'withdraw_screen.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
              decoration: const BoxDecoration(
                color: AppColors.teal,
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(24), bottomRight: Radius.circular(24)),
              ),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back, color: AppColors.cream),
                    ),
                  ),
                  const Text('মোট ব্যালেন্স',
                      style: TextStyle(color: AppColors.goldSoft, fontSize: 12, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text('৳ ${wallet.state.balanceBdt.toStringAsFixed(2)}',
                      style: const TextStyle(color: AppColors.cream, fontSize: 34, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: wallet.canWithdraw
                              ? () => Navigator.push(
                                  context, MaterialPageRoute(builder: (_) => const WithdrawScreen()))
                              : () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                  content: Text(
                                      'সর্বনিম্ন ৳${WalletProvider.minWithdraw.toStringAsFixed(0)} লাগবে উইথড্র করতে'))),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.gold,
                            foregroundColor: AppColors.tealDeep,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          child: const Text('উইথড্র করুন', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text('সাম্প্রতিক লেনদেন', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.teal)),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: wallet.state.transactions.isEmpty
                  ? const Center(
                      child: Text('এখনো কোনো লেনদেন হয়নি', style: TextStyle(color: AppColors.muted)))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: wallet.state.transactions.length,
                      itemBuilder: (context, i) {
                        final t = wallet.state.transactions[i];
                        final isCredit = t.amount >= 0;
                        return Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.teal.withOpacity(0.12)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(t.title, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                                  Text(t.date, style: const TextStyle(fontSize: 10, color: AppColors.muted)),
                                ],
                              ),
                              Text(
                                '${isCredit ? '+' : ''}৳${t.amount.toStringAsFixed(2)}',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12.5,
                                  color: isCredit ? const Color(0xFF1E8A5F) : AppColors.coral,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
