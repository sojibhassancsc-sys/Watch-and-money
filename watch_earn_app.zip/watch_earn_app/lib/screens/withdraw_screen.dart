import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../services/wallet_provider.dart';

class WithdrawScreen extends StatefulWidget {
  const WithdrawScreen({super.key});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  final _amountController = TextEditingController();
  final _phoneController = TextEditingController();
  String _method = 'bKash';
  bool _submitting = false;

  @override
  void dispose() {
    _amountController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _submit(WalletProvider wallet) async {
    final amount = double.tryParse(_amountController.text.trim());
    final phone = _phoneController.text.trim();

    if (amount == null || amount < WalletProvider.minWithdraw) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('সর্বনিম্ন ৳${WalletProvider.minWithdraw.toStringAsFixed(0)} উইথড্র করতে হবে')));
      return;
    }
    if (amount > wallet.state.balanceBdt) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ব্যালেন্সে পর্যাপ্ত টাকা নেই')));
      return;
    }
    if (phone.length < 11) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সঠিক মোবাইল নম্বর দিন')));
      return;
    }

    setState(() => _submitting = true);
    final ok = await wallet.requestWithdraw(amount, _method, phone);
    setState(() => _submitting = false);

    if (ok && mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('উইথড্র রিকোয়েস্ট পাঠানো হয়েছে')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.teal),
        title: const Text('উইথড্র রিকোয়েস্ট', style: TextStyle(color: AppColors.teal, fontWeight: FontWeight.bold)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('সর্বনিম্ন উইথড্র ৳${WalletProvider.minWithdraw.toStringAsFixed(2)} · ব্যালেন্স ৳${wallet.state.balanceBdt.toStringAsFixed(2)}',
                style: const TextStyle(color: AppColors.muted, fontSize: 12)),
            const SizedBox(height: 18),

            const Text('পরিমাণ', style: TextStyle(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: _fieldDecoration('৳ পরিমাণ লিখুন'),
            ),

            const SizedBox(height: 16),
            const Text('মেথড বেছে নিন', style: TextStyle(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Row(
              children: ['bKash', 'Nagad', 'Rocket'].map((m) {
                final active = _method == m;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _method = m),
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: active ? AppColors.goldSoft : Colors.white,
                        border: Border.all(color: active ? AppColors.gold : AppColors.teal.withOpacity(0.15), width: 1.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(m,
                          style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.bold,
                              color: active ? AppColors.tealDeep : AppColors.muted)),
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 16),
            const Text('মোবাইল নম্বর', style: TextStyle(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: _fieldDecoration('01xxx-xxxxxx'),
            ),

            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.coral.withOpacity(0.08),
                border: const Border(left: BorderSide(color: AppColors.coral, width: 3)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('প্রসেসিং সময়: ১-৩ কার্যদিবস। গেটওয়ে ফি প্রযোজ্য।',
                  style: TextStyle(fontSize: 11, color: Color(0xFF8A3627))),
            ),

            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submitting ? null : () => _submit(wallet),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.teal,
                  foregroundColor: AppColors.gold,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: _submitting
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('রিকোয়েস্ট পাঠান', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _fieldDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: AppColors.teal.withOpacity(0.15)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: AppColors.teal.withOpacity(0.15)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: AppColors.gold, width: 1.5),
      ),
    );
  }
}
