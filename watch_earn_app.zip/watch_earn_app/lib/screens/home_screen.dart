import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../services/wallet_provider.dart';
import '../services/ad_service.dart';
import 'wallet_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AdService _adService = AdService();
  bool _watchingAd = false;

  @override
  void initState() {
    super.initState();
    _adService.initialize();
  }

  @override
  void dispose() {
    _adService.dispose();
    super.dispose();
  }

  void _onWatchPressed(WalletProvider wallet) {
    if (!wallet.canWatchMoreToday) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('আজকের ভিডিও দেখার লিমিট শেষ, কাল আবার চেষ্টা করুন')),
      );
      return;
    }

    setState(() => _watchingAd = true);

    _adService.showRewardedAd(
      onRewardEarned: () async {
        await wallet.creditVideoReward();
        if (mounted) setState(() => _watchingAd = false);
      },
      onAdNotReady: () {
        if (mounted) {
          setState(() => _watchingAd = false);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('বিজ্ঞাপন লোড হচ্ছে, একটু পর আবার চেষ্টা করুন')),
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    final progress = wallet.state.videosWatchedToday / WalletProvider.dailyVideoLimit;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // --- Top teal header with balance card ---
              Container(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 26),
                decoration: const BoxDecoration(
                  color: AppColors.teal,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(24),
                    bottomRight: Radius.circular(24),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('শুভ সকাল 👋',
                        style: TextStyle(color: AppColors.goldSoft, fontSize: 13, fontWeight: FontWeight.w500)),
                    const SizedBox(height: 2),
                    const Text('স্বাগতম',
                        style: TextStyle(color: AppColors.cream, fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(color: AppColors.gold, borderRadius: BorderRadius.circular(16)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('মোট ব্যালেন্স',
                                  style: TextStyle(fontSize: 11, color: AppColors.tealDeep, fontWeight: FontWeight.w600)),
                              Text('৳ ${wallet.state.balanceBdt.toStringAsFixed(2)}',
                                  style: const TextStyle(
                                      fontSize: 26, color: AppColors.tealDeep, fontWeight: FontWeight.bold)),
                            ],
                          ),
                          GestureDetector(
                            onTap: () => Navigator.push(
                                context, MaterialPageRoute(builder: (_) => const WalletScreen())),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              decoration:
                                  BoxDecoration(color: AppColors.tealDeep, borderRadius: BorderRadius.circular(20)),
                              child: const Text('উইথড্র',
                                  style: TextStyle(
                                      color: AppColors.gold, fontSize: 11, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // --- Daily progress ring ---
              Center(
                child: SizedBox(
                  width: 140,
                  height: 140,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 140,
                        height: 140,
                        child: CircularProgressIndicator(
                          value: progress.clamp(0, 1),
                          strokeWidth: 10,
                          backgroundColor: AppColors.teal.withOpacity(0.1),
                          valueColor: const AlwaysStoppedAnimation(AppColors.gold),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('${wallet.state.videosWatchedToday}/${WalletProvider.dailyVideoLimit}',
                              style: const TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.teal)),
                          const Text('আজকের ভিউ',
                              style: TextStyle(fontSize: 10, color: AppColors.muted, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // --- Watch video CTA ---
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ElevatedButton(
                  onPressed: _watchingAd ? null : () => _onWatchPressed(wallet),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.coral,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: _watchingAd
                      ? const SizedBox(
                          height: 20, width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : Column(
                          children: [
                            const Text('▶ ভিডিও দেখুন',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                            Text('+৳${WalletProvider.rewardPerVideo.toStringAsFixed(2)} পাবেন',
                                style: const TextStyle(fontSize: 10, color: Colors.white70)),
                          ],
                        ),
                ),
              ),

              const SizedBox(height: 24),

              // --- Task list ---
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('আজকের টাস্ক',
                        style: TextStyle(fontSize: 12, color: AppColors.muted, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    _TaskTile(
                      icon: '🎬',
                      title: 'রিওয়ার্ড ভিডিও',
                      subtitle: '৩০ সেকেন্ড',
                      reward: '+৳${WalletProvider.rewardPerVideo.toStringAsFixed(2)}',
                    ),
                    _TaskTile(
                      icon: '🔥',
                      title: 'দৈনিক স্ট্রিক',
                      subtitle: '${wallet.state.dailyStreak} দিন চলছে',
                      reward: '+৳2.00',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  final String icon, title, subtitle, reward;
  const _TaskTile({required this.icon, required this.title, required this.subtitle, required this.reward});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.teal.withOpacity(0.12)),
      ),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(color: AppColors.teal, borderRadius: BorderRadius.circular(9)),
            alignment: Alignment.center,
            child: Text(icon, style: const TextStyle(fontSize: 16)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                Text(subtitle, style: const TextStyle(fontSize: 10.5, color: AppColors.muted)),
              ],
            ),
          ),
          Text(reward, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.teal)),
        ],
      ),
    );
  }
}
