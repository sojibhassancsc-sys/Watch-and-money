import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'theme.dart';
import 'services/wallet_provider.dart';
import 'screens/home_screen.dart';
import 'screens/wallet_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env'); // Ad ID ও API URL এখান থেকে লোড হয়
  runApp(const WatchEarnApp());
}

class WatchEarnApp extends StatelessWidget {
  const WatchEarnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => WalletProvider()..load(),
      child: MaterialApp(
        title: 'Watch & Earn',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        home: const RootNav(),
      ),
    );
  }
}

/// নিচের bottom navigation bar দিয়ে Home ও Wallet-এর মধ্যে সুইচ করা যায়।
/// (ডিজাইন প্রিভিউয়ে দেখানো নেভিগেশনের সাথে মিলিয়ে)
class RootNav extends StatefulWidget {
  const RootNav({super.key});

  @override
  State<RootNav> createState() => _RootNavState();
}

class _RootNavState extends State<RootNav> {
  int _index = 0;

  final _screens = const [HomeScreen(), WalletScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        selectedItemColor: AppColors.teal,
        unselectedItemColor: AppColors.muted,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'হোম'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet_rounded), label: 'ওয়ালেট'),
        ],
      ),
    );
  }
}
