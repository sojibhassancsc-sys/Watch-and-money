class TransactionItem {
  final String title;
  final String date;
  final double amount; // positive = credit (আয়), negative = debit (উইথড্র)

  TransactionItem({required this.title, required this.date, required this.amount});

  Map<String, dynamic> toJson() => {
        'title': title,
        'date': date,
        'amount': amount,
      };

  factory TransactionItem.fromJson(Map<String, dynamic> json) => TransactionItem(
        title: json['title'],
        date: json['date'],
        amount: (json['amount'] as num).toDouble(),
      );
}

class WalletState {
  double balanceBdt;
  int videosWatchedToday;
  int dailyStreak;
  List<TransactionItem> transactions;

  WalletState({
    this.balanceBdt = 0,
    this.videosWatchedToday = 0,
    this.dailyStreak = 0,
    List<TransactionItem>? transactions,
  }) : transactions = transactions ?? [];
}
