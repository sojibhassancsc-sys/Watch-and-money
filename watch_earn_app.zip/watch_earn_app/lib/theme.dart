import 'package:flutter/material.dart';

class AppColors {
  static const teal = Color(0xFF0B3D3A);
  static const tealDeep = Color(0xFF082A28);
  static const gold = Color(0xFFE8B84B);
  static const goldSoft = Color(0xFFF3D68B);
  static const cream = Color(0xFFFBF7EF);
  static const coral = Color(0xFFE8604C);
  static const ink = Color(0xFF152220);
  static const muted = Color(0xFF6B8481);
}

ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: AppColors.cream,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.teal,
      primary: AppColors.teal,
      secondary: AppColors.gold,
      surface: AppColors.cream,
    ),
    fontFamily: 'HindSiliguri', // pubspec.yaml-এ ফন্ট যোগ করুন, নাহলে system default ব্যবহার হবে
  );
}
