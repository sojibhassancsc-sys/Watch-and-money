import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// ভিডিও অ্যাড লোড ও দেখানোর পুরো লজিক এখানে।
///
/// কৌশল: আগে AdMob দিয়ে চেষ্টা করে, লোড ব্যর্থ হলে Start.io দিয়ে চেষ্টা করে
/// (সহজ ওয়াটারফল)। AdMob কনসোলে নিজে থেকে Start.io-কে "Mediation Partner"
/// হিসেবে যোগ করলে এই ম্যানুয়াল ফলব্যাক লজিক আর লাগবে না — AdMob নিজেই
/// দুটো নেটওয়ার্কের মধ্যে সেরা eCPM বেছে নেবে। এই ফাইলে দুটো পদ্ধতিই
/// বোঝার জন্য আলাদা রাখা হলো।
class AdService {
  static String get _admobRewardedUnitId {
    // Android/iOS আলাদা — বিল্ড টাইমে TargetPlatform অনুযায়ী পরিবর্তন করুন
    return dotenv.env['ADMOB_REWARDED_AD_UNIT_ID_ANDROID'] ?? '';
  }

  RewardedAd? _rewardedAd;
  bool _isLoading = false;

  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    // Start.io SDK init এখানে যোগ করুন, উদাহরণ:
    // await StartAppSdk().init(dotenv.env['STARTIO_APP_ID_ANDROID'] ?? '');
    _loadAd();
  }

  void _loadAd() {
    if (_isLoading) return;
    _isLoading = true;

    RewardedAd.load(
      adUnitId: _admobRewardedUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isLoading = false;
        },
        onAdFailedToLoad: (error) {
          _isLoading = false;
          _rewardedAd = null;
          // 🔴 TODO: AdMob লোড ব্যর্থ হলে এখানে Start.io SDK দিয়ে
          // ফলব্যাক rewarded ad লোড করার কোড বসান।
          // print('AdMob load failed: $error — trying Start.io fallback');
        },
      ),
    );
  }

  bool get isAdReady => _rewardedAd != null;

  /// ভিডিও দেখান, সম্পূর্ণ দেখলে onRewardEarned কল হবে।
  /// onRewardEarned-এর ভেতরেই WalletProvider.creditVideoReward() কল করবেন —
  /// শুধু ভিডিও শুরু হলে না, সম্পূর্ণ শেষ হলে রিওয়ার্ড দিন, এটাই AdMob নীতি।
  void showRewardedAd({
    required Function() onRewardEarned,
    required Function() onAdNotReady,
  }) {
    if (_rewardedAd == null) {
      onAdNotReady();
      _loadAd();
      return;
    }

    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
        _loadAd(); // পরের বার দেখানোর জন্য নতুন অ্যাড প্রি-লোড করুন
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _rewardedAd = null;
        _loadAd();
        onAdNotReady();
      },
    );

    _rewardedAd!.show(
      onUserEarnedReward: (ad, reward) {
        onRewardEarned();
      },
    );
  }

  void dispose() {
    _rewardedAd?.dispose();
  }
}
