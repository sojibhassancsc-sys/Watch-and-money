import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

/// আপনার নিজের Node.js/Firebase ব্যাকএন্ডের সাথে কথা বলার জায়গা।
/// এখন এটা শুধু স্ট্রাকচার — আসল ব্যাকএন্ড রেডি হলে এই ফাংশনগুলো
/// wallet_provider.dart-এর 🔴 TODO জায়গাগুলোতে কল করবেন।
class BackendService {
  static String get _baseUrl => dotenv.env['API_BASE_URL'] ?? '';

  /// সার্ভার-সাইড ভেরিফিকেশনসহ ভিডিও রিওয়ার্ড ক্রেডিট করা।
  /// AdMob-এর SSV (Server-Side Verification) কলব্যাক ব্যবহার করলে সবচেয়ে
  /// নিরাপদ — ক্লায়েন্ট থেকে সরাসরি ক্রেডিট কল করলে রিভার্স-ইঞ্জিনিয়ার করে
  /// ফেক রিওয়ার্ড কল করা সম্ভব, তাই প্রোডাকশনে SSV সেটআপ করা জরুরি।
  static Future<bool> creditReward({required String userId, required double amount}) async {
    try {
      final res = await http.post(
        Uri.parse('$_baseUrl/reward'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'userId': userId, 'amount': amount}),
      );
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> requestWithdraw({
    required String userId,
    required double amount,
    required String method,
    required String phone,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$_baseUrl/withdraw'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'userId': userId,
          'amount': amount,
          'method': method,
          'phone': phone,
        }),
      );
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}
