import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/wallet.dart';

/// এই ক্লাসটা পুরো অ্যাপের ব্যালেন্স/স্ট্রিক/লেনদেন হিসাব রাখে।
///
/// ⚠️ গুরুত্বপূর্ণ: এখানে শুধু ডিভাইসে (SharedPreferences) হিসাব রাখা হচ্ছে —
/// প্রোডাকশনে এটা অবশ্যই আপনার ব্যাকএন্ড API-এর সাথে sync করতে হবে, নাহলে
/// ইউজার অ্যাপ আনইনস্টল করলে বা ডিভাইস বদলালে ব্যালেন্স হারিয়ে যাবে,
/// এবং কেউ চাইলে লোকাল ডেটা এডিট করে ব্যালেন্স বাড়িয়ে ফেলতে পারবে (fraud risk)।
/// backend_service.dart-এ API কল করার জায়গা রাখা আছে — সেটা যুক্ত করুন।
class WalletProvider extends ChangeNotifier {
  static const _kBalance = 'wallet_balance';
  static const _kVideosToday = 'videos_today';
  static const _kStreak = 'daily_streak';
  static const _kLastWatchDate = 'last_watch_date';
  static const _kTransactions = 'transactions';

  static const double rewardPerVideo = 0.85; // .env / ব্যাকএন্ড থেকে নিয়ন্ত্রিত হওয়া উচিত
  static const int dailyVideoLimit = 10;
  static const double minWithdraw = 50;

  final WalletState state = WalletState();
  bool _loaded = false;
  bool get loaded => _loaded;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    state.balanceBdt = prefs.getDouble(_kBalance) ?? 0;
    state.dailyStreak = prefs.getInt(_kStreak) ?? 0;

    final lastDate = prefs.getString(_kLastWatchDate);
    final today = _todayKey();
    if (lastDate == today) {
      state.videosWatchedToday = prefs.getInt(_kVideosToday) ?? 0;
    } else {
      // নতুন দিন শুরু — আজকের ভিউ কাউন্ট রিসেট
      state.videosWatchedToday = 0;
    }

    final txnJson = prefs.getString(_kTransactions);
    if (txnJson != null) {
      final List list = jsonDecode(txnJson);
      state.transactions = list.map((e) => TransactionItem.fromJson(e)).toList();
    }

    _loaded = true;
    notifyListeners();
  }

  String _todayKey() {
    final now = DateTime.now();
    return '${now.year}-${now.month}-${now.day}';
  }

  bool get canWatchMoreToday => state.videosWatchedToday < dailyVideoLimit;

  /// রিওয়ার্ডেড ভিডিও সম্পূর্ণ দেখা শেষ হলে এই মেথড কল হবে (ad_service থেকে)।
  Future<void> creditVideoReward() async {
    if (!canWatchMoreToday) return;

    state.balanceBdt += rewardPerVideo;
    state.videosWatchedToday += 1;
    state.transactions.insert(
      0,
      TransactionItem(title: 'ভিডিও রিওয়ার্ড', date: 'আজ', amount: rewardPerVideo),
    );

    // স্ট্রিক আপডেট
    final prefs = await SharedPreferences.getInstance();
    final lastDate = prefs.getString(_kLastWatchDate);
    final today = _todayKey();
    if (lastDate != today) {
      state.dailyStreak += 1;
    }

    await prefs.setDouble(_kBalance, state.balanceBdt);
    await prefs.setInt(_kVideosToday, state.videosWatchedToday);
    await prefs.setInt(_kStreak, state.dailyStreak);
    await prefs.setString(_kLastWatchDate, today);
    await prefs.setString(_kTransactions, jsonEncode(state.transactions.map((e) => e.toJson()).toList()));

    // 🔴 TODO (ব্যাকএন্ড ইন্টিগ্রেশন): এখানে আপনার সার্ভারে একটা কল করুন যাতে
    // সার্ভার-সাইডেও ভেরিফাই ও রেকর্ড হয় — শুধু ডিভাইসে ব্যালেন্স রাখলে
    // ইউজার সহজেই ম্যানিপুলেট করতে পারবে। উদাহরণ: BackendService.creditReward(...)

    notifyListeners();
  }

  bool get canWithdraw => state.balanceBdt >= minWithdraw;

  Future<bool> requestWithdraw(double amount, String method, String phone) async {
    if (amount < minWithdraw || amount > state.balanceBdt) return false;

    // 🔴 TODO (ব্যাকএন্ড ইন্টিগ্রেশন): সরাসরি ব্যালেন্স থেকে বাদ না দিয়ে
    // এখানে ব্যাকএন্ডে একটা "withdraw request" পাঠানো উচিত, ব্যাকএন্ড অ্যাডমিন
    // অ্যাপ্রুভ করার পর ব্যালেন্স কাটবে। নিচেরটা শুধু UI ডেমোর জন্য সরলীকৃত।

    state.balanceBdt -= amount;
    state.transactions.insert(
      0,
      TransactionItem(title: '$method উইথড্র', date: 'আজ', amount: -amount),
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kBalance, state.balanceBdt);
    await prefs.setString(_kTransactions, jsonEncode(state.transactions.map((e) => e.toJson()).toList()));

    notifyListeners();
    return true;
  }
}
