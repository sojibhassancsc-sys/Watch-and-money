# Watch & Earn App — Flutter প্রজেক্ট

ভিডিও দেখে টাকা আয় করার অ্যাপের সোর্স কোড। AdMob + Start.io দিয়ে বিজ্ঞাপন দেখানো, wallet/withdraw সিস্টেম।

## ⚠️ পাবলিশ করার আগে অবশ্যই করতে হবে
1. `.env` ফাইলে থাকা AdMob/Start.io Test ID-গুলো নিজের **আসল ID** দিয়ে বদলান
2. `android/app/src/main/AndroidManifest.xml`-এ `APPLICATION_ID` বদলান
3. `lib/services/backend_service.dart`-এ নিজের ব্যাকএন্ড API URL বসান — এখন এটা শুধু স্ট্রাকচার, আসল সার্ভার ছাড়া কাজ করবে না
4. `lib/services/wallet_provider.dart`-এর 🔴 TODO কমেন্ট করা জায়গাগুলোতে ব্যাকএন্ড কল যুক্ত করুন — এখন ব্যালেন্স শুধু ডিভাইসে (SharedPreferences) থাকে, যা প্রোডাকশনের জন্য যথেষ্ট নিরাপদ না

## GitHub-এ আপলোড করবেন কীভাবে (মোবাইল থেকে)

**Android (Chrome ব্রাউজার দিয়ে)**
1. github.com-এ লগইন করুন, নতুন repo বানান
2. মোবাইল Chrome-এ ⋮ মেনু থেকে **"Desktop site"** চালু করুন
3. repo-তে ঢুকে **Add file → Upload files**
4. এই পুরো ফোল্ডারের সব ফাইল সিলেক্ট করে আপলোড করুন (ফোল্ডার স্ট্রাকচার ঠিক রাখতে ZIP না করে ফাইল ম্যানেজার থেকে সব ফাইল/সাবফোল্ডার একসাথে সিলেক্ট করুন)

**iPhone**
1. App Store থেকে **Working Copy** অ্যাপ ইনস্টল করুন (ফ্রি ভার্সনেই যথেষ্ট)
2. GitHub-এ repo বানিয়ে তার URL Working Copy-তে clone করুন
3. এই ফাইলগুলো Working Copy-এর ফাইল ব্রাউজারে কপি করে commit ও push করুন

## Codemagic দিয়ে APK বিল্ড করা (ব্রাউজার থেকেই, কম্পিউটার ছাড়া)

1. [codemagic.io](https://codemagic.io)-তে GitHub একাউন্ট দিয়ে সাইন আপ করুন
2. **Add application** → আপনার GitHub repo সিলেক্ট করুন, Codemagic নিজেই Flutter প্রজেক্ট শনাক্ত করবে
3. প্রথমবার build করার আগে Codemagic-এ একটা **Android keystore** বানাতে হবে (অ্যাপ সাইন করার জন্য) — Codemagic-এর "Android code signing" সেকশনে এটা এক ক্লিকে জেনারেট করা যায়
4. **Start new build** চাপুন — কোড কম্পাইল হয়ে APK বানাবে (৫-১৫ মিনিট লাগতে পারে)
5. বিল্ড শেষ হলে `codemagic.yaml`-এ দেওয়া ইমেইলে APK-এর ডাউনলোড লিংক আসবে, অথবা Codemagic ড্যাশবোর্ড থেকেই সরাসরি ডাউনলোড করা যাবে

## GitHub Releases-এ APK রাখা (ইউজারদের সরাসরি ডাউনলোড দিতে)
Codemagic থেকে পাওয়া APK ফাইলটা GitHub repo-র **Releases** সেকশনে (repo পেজে ডান পাশে "Releases" লিংক) আপলোড করে রাখলে, যে কেউ সেই লিংক থেকে সরাসরি APK ডাউনলোড করে ইনস্টল করতে পারবে (Play Store পাবলিশ হওয়ার আগেই টেস্টিং-এর জন্য এটা কাজে লাগবে)।

## প্রজেক্ট স্ট্রাকচার
```
lib/
  main.dart              → অ্যাপ শুরু হওয়ার জায়গা
  theme.dart             → রং, ফন্ট থিম
  models/wallet.dart     → ব্যালেন্স/লেনদেনের ডেটা মডেল
  services/
    ad_service.dart       → AdMob/Start.io বিজ্ঞাপন দেখানোর লজিক
    wallet_provider.dart  → ব্যালেন্স হিসাব ও state management
    backend_service.dart  → ব্যাকএন্ড API-এর সাথে কথা বলার জায়গা (স্ট্রাকচার)
  screens/
    home_screen.dart      → ভিডিও দেখার মূল স্ক্রিন
    wallet_screen.dart     → ব্যালেন্স ও লেনদেন হিস্ট্রি
    withdraw_screen.dart   → উইথড্র রিকোয়েস্ট ফর্ম
```
